//Create a reference for canvas 
canvas = document.getElementById('myCanvas');
ctx = canvas.getContext("2d");

//Give specific height and width to the car image
car_height = 100;
car_width = 75;
background_image = "parkingLot.jpg";
greencar_image = "car2.png";

//Set initial position for a car image.
car_x = 5;
car_y = 225;
function add() {
	//upload car, and background images on the canvas.
	b_i_t = new Image();
    b_i_t.onload = uploadBackground;
    b_i_t.src = background_image;

    r_i_t = new Image();
    r_i_t.onload = uploadgreencar;
    r_i_t.src = greencar_image;
}

function uploadBackground() {
	//Define function ‘uploadBackground’
	ctx.drawImage(b_i_t,0,0,canvas.width,canvas.height);
}

function uploadgreencar() {
	//Define function ‘uploadgreencar’.
	ctx.drawImage(r_i_t,car_x,car_y,car_width,car_height);
	
}


window.addEventListener("keydown", my_keydown);

function my_keydown(e)
{
	keyPressed = e.keyCode;
	console.log(keyPressed);
		if(keyPressed == '38')
		{
			up();
			console.log("up");
		}
	
		if(keyPressed == '40')
		{
			down();
			console.log("down");
		}
		
		if(keyPressed == '37')
		{
			left();
			console.log("left");
		}
	
		if(keyPressed == '39')
		{
			right();
			console.log("right");
		}
		
		
}

function up(){
    if(r_y>=0){
        r_y= r_y - 15;
        console.log("When up arrow is pressed,x = "+ car_x +",y = " +car_y);
        u_b();
        r_b();
    }
}

function down(){
    if(car_y<=600){
        car_y= car_y + 15;
        console.log("When down arrow is pressed,x = "+ car_x +",y = " +car_y);
        u_b();
        r_b();
    }
}

function left(){
    if(car_x>=0){
        car_x= car_x - 15;
        console.log("When left arrow is pressed,x = "+ car_x +",y = " +r_y);
        u_b();
        r_b();
    }
}

function right(){
    if(car_x<=500){
        car_x= car_x + 15;
        console.log("When right arrow is pressed,x = "+ car_x +",y = " +r_y);
        u_b();
        r_b();
    }
}